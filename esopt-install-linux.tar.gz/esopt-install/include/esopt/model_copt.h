#pragma once

#include "solvers/copt/copt.h"

#include "model_base.h"
#include "dylib.h"
#include "variable_expression.h"
#include "constraint.h"

#include <memory>

// COPT C API function list
#define COPT_APILIST                    \
    B(COPT_GetRetcodeMsg);              \
    B(COPT_CreateProb);                 \
    B(COPT_DeleteProb);                 \
    B(COPT_AddCol);                     \
    B(COPT_DelCols);                    \
    B(COPT_AddRow);                     \
    B(COPT_AddQConstr);                 \
    B(COPT_AddSOSs);                    \
    B(COPT_AddCones);                   \
    B(COPT_AddExpCones);                \
    B(COPT_AddNLConstr);                \
    B(COPT_DelRows);                    \
    B(COPT_DelQConstrs);                \
    B(COPT_DelSOSs);                    \
    B(COPT_DelCones);                   \
    B(COPT_DelExpCones);                \
    B(COPT_DelQuadObj);                 \
    B(COPT_DelNLObj);                   \
    B(COPT_ReplaceColObj);              \
    B(COPT_SetObjConst);                \
    B(COPT_SetObjSense);                \
    B(COPT_SetQuadObj);                 \
    B(COPT_SetNLObj);                   \
    B(COPT_SetIntParam);                \
    B(COPT_SetDblParam);                \
    B(COPT_GetIntParam);                \
    B(COPT_GetDblParam);                \
    B(COPT_GetIntAttr);                 \
    B(COPT_GetDblAttr);                 \
    B(COPT_GetColInfo);                 \
    B(COPT_GetColName);                 \
    B(COPT_SetColNames);                \
    B(COPT_GetColType);                 \
    B(COPT_SetColType);                 \
    B(COPT_SetColLower);                \
    B(COPT_SetColUpper);                \
    B(COPT_GetRowInfo);                 \
    B(COPT_GetQConstrInfo);             \
    B(COPT_GetNLConstrInfo);            \
    B(COPT_GetRowName);                 \
    B(COPT_GetQConstrName);             \
    B(COPT_GetNLConstrName);            \
    B(COPT_SetRowNames);                \
    B(COPT_SetQConstrNames);            \
    B(COPT_SetNLConstrNames);           \
    B(COPT_AddMipStart);                \
    B(COPT_GetQConstrRhs);              \
    B(COPT_SetRowLower);                \
    B(COPT_SetRowUpper);                \
    B(COPT_SetQConstrRhs);              \
    B(COPT_GetElem);                    \
    B(COPT_SetElem);                    \
    B(COPT_SetColObj);                  \
    B(COPT_GetBanner);                  \
    B(COPT_Solve);                      \
    B(COPT_GetSolution);                \
    B(COPT_CreateEnv);                  \
    B(COPT_DeleteEnv);                  \
    B(COPT_CreateEnvConfig);            \
    B(COPT_DeleteEnvConfig);            \
    B(COPT_SetEnvConfig);               \
    B(COPT_CreateEnvWithConfig);        \
    B(COPT_ComputeIIS);                 \
    B(COPT_GetColLowerIIS);             \
    B(COPT_GetColUpperIIS);             \
    B(COPT_GetRowLowerIIS);             \
    B(COPT_GetRowUpperIIS);             \
    B(COPT_GetSOSIIS);                  \
    B(COPT_SetCallback);                \
    B(COPT_GetCallbackInfo);            \
    B(COPT_AddCallbackSolution);        \
    B(COPT_AddCallbackLazyConstr);      \
    B(COPT_AddCallbackUserCut);         \
    B(COPT_Interrupt);                  \
    B(COPT_WriteMps);                   \
    B(COPT_WriteLp);                    \
    B(COPT_WriteCbf);                   \
    B(COPT_WriteBin);                   \
    B(COPT_WriteSol);                   \
    B(COPT_WriteMst);                   \
    B(COPT_WriteParam);                 \
    B(COPT_WriteBasis);

namespace copt
{
#define B DYLIB_EXTERN_DECLARE
COPT_APILIST
#undef B

bool is_library_loaded();
bool MODEL_API load_library(const std::string &path);
} // namespace copt

/// COPT environment configuration
/// Used to configure the COPT environment before creation
class MODEL_API COPTEnvConfig
{
  public:
    COPTEnvConfig();
    ~COPTEnvConfig();

    void set(const char *param_name, const char *value);

  private:
    copt_env_config *m_config = nullptr;

    friend class COPTEnv;
};

/// COPT environment
/// Manages the COPT solver environment including licensing
class MODEL_API COPTEnv
{
  public:
    COPTEnv();
    COPTEnv(COPTEnvConfig &config);
    ~COPTEnv();

    void close();

  private:
    copt_env *m_env = nullptr;

    friend class COPTModel;
};

/// MonotoneIndexer - tracks alive/deleted indices for constraint management
class MODEL_API MonotoneIndexer
{
  public:
    IndexT add_index()
    {
        if (m_free_indices.empty())
        {
            IndexT idx = m_next++;
            m_alive.push_back(true);
            return idx;
        }
        IndexT idx = m_free_indices.back();
        m_free_indices.pop_back();
        m_alive[idx] = true;
        return idx;
    }

    void delete_index(IndexT idx)
    {
        if (idx >= 0 && idx < static_cast<IndexT>(m_alive.size()) && m_alive[idx])
        {
            m_alive[idx] = false;
            m_free_indices.push_back(idx);
        }
    }

    IndexT get_index(IndexT idx) const
    {
        if (idx >= 0 && idx < static_cast<IndexT>(m_alive.size()) && m_alive[idx])
        {
            return m_index_map[idx];
        }
        return -1;
    }

    bool has_index(IndexT idx) const
    {
        return idx >= 0 && idx < static_cast<IndexT>(m_alive.size()) && m_alive[idx];
    }

    void set_copt_row(IndexT user_idx, int copt_row)
    {
        while (static_cast<IndexT>(m_index_map.size()) <= user_idx)
        {
            m_index_map.push_back(-1);
        }
        m_index_map[user_idx] = copt_row;
    }

  private:
    IndexT m_next = 0;
    std::vector<bool> m_alive;
    std::vector<IndexT> m_free_indices;
    std::vector<int> m_index_map;
};

/// COPT custom deleter for copt_prob
struct COPTfreemodelT
{
    void operator()(copt_prob *model) const
    {
        copt::COPT_DeleteProb(&model);
    }
};

/// COPT callback userdata
struct COPTCallbackUserdata
{
    void *model = nullptr;
    using COPTCallback = std::function<void(void *model, int cbctx)>;
    COPTCallback callback;
    int n_variables = 0;
    int where = 0;

    // store result of cbget
    bool cb_get_mipsol_called = false;
    std::vector<double> mipsol;
    bool cb_get_mipnoderel_called = false;
    std::vector<double> mipnoderel;
    bool cb_get_mipincumbent_called = false;
    std::vector<double> mipincumbent;

    // Cache for cbsolution
    bool cb_set_solution_called = false;
    std::vector<double> heuristic_solution;
    bool cb_requires_submit_solution = false;
};

/// COPT solver model - wraps COPT optimization library
/// Inherits from ModelBase providing unified API for linear and quadratic optimization
class MODEL_API COPTModel : public ModelBase
{
  public:
    using ModelBase::set_parameter;

    COPTModel();
    explicit COPTModel(const COPTEnv &env);
    explicit COPTModel(COPTEnvConfig &config);
    ~COPTModel();

    void init();
    void init(const COPTEnv &env);
    void close();

    double get_infinity() const;

    // Write model to file
    void write(const std::string &filename);

    // Add variable
    VariableIndex add_variable(double lb, double ub, VariableDomain domain = VariableDomain::Continuous,
                               const char *name = nullptr) override;

    // Delete variable
    void delete_variable(const VariableIndex &variable);
    bool is_variable_active(const VariableIndex &variable);

    // Add linear constraint (sense-based)
    ConstraintIndex add_linear_constraint(const ScalarAffineFunction &f, ConstraintSense sense, double rhs,
                                          const char *name = nullptr) override;

    // Add linear constraint (interval-based)
    ConstraintIndex add_linear_constraint(const ScalarAffineFunction &f,
                                          const std::tuple<double, double> &interval,
                                          const char *name = nullptr) override;

    // Add quadratic constraint
    ConstraintIndex add_quadratic_constraint(const ScalarQuadraticFunction &f,
                                             ConstraintSense sense, double rhs,
                                             const char *name = nullptr) override;

    // Add SOS constraint
    ConstraintIndex add_sos_constraint(const Vector<VariableIndex> &variables, int sos_type);

    // Add second-order cone constraint
    ConstraintIndex add_second_order_cone_constraint(const Vector<VariableIndex> &variables, bool rotated = false);

    // Add exponential cone constraint
    ConstraintIndex add_exp_cone_constraint(const Vector<VariableIndex> &variables, bool dual = false);

    // Add nonlinear constraint (not supported by COPT MIP solver)
    NLConstraintIndex add_nl_constraint(const ExpressionHandle &expr, ConstraintSense sense, double rhs,
                                        const char *name = nullptr) override;

    // Delete constraint
    void delete_constraint(const ConstraintIndex &constraint);
    bool is_constraint_active(const ConstraintIndex &constraint);

    // Set linear/quadratic objective
    void set_objective(const ScalarAffineFunction &expr, ObjectiveSense sense = ObjectiveSense::Minimize) override;
    void set_objective(const ExprBuilder &expr, ObjectiveSense sense = ObjectiveSense::Minimize) override;

    // Add nonlinear objective (not supported by COPT MIP solver)
    void add_nl_objective(const ExpressionHandle &expr) override;

    // Solve the model
    void optimize() override;

    // Set variable bounds
    void set_variable_bounds(const VariableIndex &variable, double lb, double ub) override;

    // Get variable value
    double get_variable_value(const VariableIndex &variable) override;

    // Model attribute support
    bool supports_model_attribute(ModelAttributeDouble attribute, bool changeable) override;
    bool supports_model_attribute(ModelAttributeInt attribute, bool changeable) override;
    bool supports_model_attribute(ModelAttributeString attribute, bool changeable) override;
    double get_model_attribute(ModelAttributeDouble attribute) override;
    int get_model_attribute(ModelAttributeInt attribute) override;
    std::string get_model_attribute(ModelAttributeString attribute) override;
    void set_model_attribute(ModelAttributeDouble attribute, double value) override;
    void set_model_attribute(ModelAttributeInt attribute, int value) override;
    void set_model_attribute(ModelAttributeString attribute, const char *value) override;

    // Variable attribute support
    bool supports_variable_attribute(VariableAttributeDouble attribute, bool changeable) override;
    bool supports_variable_attribute(VariableAttributeInt attribute, bool changeable) override;
    bool supports_variable_attribute(VariableAttributeString attribute, bool changeable) override;
    double get_variable_attribute(const VariableIndex &variable, VariableAttributeDouble attribute) override;
    int get_variable_attribute(const VariableIndex &variable, VariableAttributeInt attribute) override;
    std::string get_variable_attribute(const VariableIndex &variable, VariableAttributeString attribute) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeDouble attribute, double value) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeInt attribute, int value) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeString attribute, const char *value) override;

    // Constraint attribute support
    bool supports_constraint_attribute(ConstraintAttributeDouble attribute, bool changeable) override;
    bool supports_constraint_attribute(ConstraintAttributeInt attribute, bool changeable) override;
    bool supports_constraint_attribute(ConstraintAttributeString attribute, bool changeable) override;
    double get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeDouble attribute) override;
    int get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeInt attribute) override;
    std::string get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeString attribute) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeDouble attribute, double value) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeInt attribute, int value) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeString attribute, const char *value) override;

    // Solver parameters
    void set_parameter(const char *name, double value) override;
    void set_parameter(const char *name, int value) override;
    void set_parameter(const char *name, const char *value) override;

    // Additional COPT-specific methods
    std::string get_variable_name(const VariableIndex &variable);
    void set_variable_name(const VariableIndex &variable, const char *name);
    VariableDomain get_variable_type(const VariableIndex &variable);
    void set_variable_type(const VariableIndex &variable, VariableDomain domain);
    double get_variable_lower_bound(const VariableIndex &variable);
    void set_variable_lower_bound(const VariableIndex &variable, double lb);
    double get_variable_upper_bound(const VariableIndex &variable);
    void set_variable_upper_bound(const VariableIndex &variable, double ub);
    std::string get_constraint_name(const ConstraintIndex &constraint);
    void set_constraint_name(const ConstraintIndex &constraint, const char *name);
    double get_constraint_primal(const ConstraintIndex &constraint);
    double get_constraint_dual(const ConstraintIndex &constraint);
    ObjectiveSense get_obj_sense();
    void set_obj_sense(ObjectiveSense sense);
    double get_obj_value();
    void add_mip_start(const Vector<VariableIndex> &variables, const Vector<double> &values);

    // Raw COPT parameter/attribute access
    void set_raw_parameter_int(const char *param_name, int value);
    void set_raw_parameter_double(const char *param_name, double value);
    int get_raw_parameter_int(const char *param_name);
    double get_raw_parameter_double(const char *param_name);
    int get_raw_attribute_int(const char *attr_name);
    double get_raw_attribute_double(const char *attr_name);

    int _variable_index(const VariableIndex &variable);
    int _constraint_index(const ConstraintIndex &constraint);

    // For callback
    bool has_callback = false;
    void *m_cbdata = nullptr;
    COPTCallbackUserdata m_callback_userdata;

    int cb_get_info_int(const std::string &what);
    double cb_get_info_double(const std::string &what);
    void cb_get_info_doublearray(const std::string &what);
    double cb_get_solution(const VariableIndex &variable);
    double cb_get_relaxation(const VariableIndex &variable);
    double cb_get_incumbent(const VariableIndex &variable);
    void cb_set_solution(const VariableIndex &variable, double value);
    double cb_submit_solution();
    void cb_exit();
    void cb_add_lazy_constraint(const ScalarAffineFunction &function, ConstraintSense sense, double rhs);
    void cb_add_user_cut(const ScalarAffineFunction &function, ConstraintSense sense, double rhs);

    // IIS related
    void computeIIS();
    int get_variable_upperbound_IIS(const VariableIndex &variable);
    int get_variable_lowerbound_IIS(const VariableIndex &variable);
    int get_constraint_IIS(const ConstraintIndex &constraint);

    // MIP start
    void set_variable_start(const VariableIndex &variable, double start);

  private:
    int _checked_variable_index(const VariableIndex &variable);
    int _checked_constraint_index(const ConstraintIndex &constraint);

    void _set_affine_objective(const ScalarAffineFunction &function, ObjectiveSense sense,
                               bool clear_quadratic);

    // State tracking
    size_t m_n_variables = 0;
    MonotoneIndexer m_linear_constraint_indexer;
    MonotoneIndexer m_quadratic_constraint_indexer;
    MonotoneIndexer m_sos_constraint_indexer;
    MonotoneIndexer m_cone_constraint_indexer;
    MonotoneIndexer m_exp_cone_constraint_indexer;
    MonotoneIndexer m_nl_constraint_indexer;

    // Mapping: user variable index -> COPT column index
    // Maintained across variable deletions to handle COPT index shifting
    std::vector<int> m_user_to_copt;
    std::vector<bool> m_var_alive;
    int m_next_copt_col = 0;

    // Solution cache
    mutable std::vector<double> m_colvalue;
    mutable std::vector<double> m_rowvalue;
    mutable std::vector<double> m_coldual;
    mutable std::vector<double> m_rowdual;
    mutable int m_model_status = -1;
    mutable bool m_has_solution = false;
    double m_objective_value = 0.0;

    /// COPT model handle (incomplete type - managed via unique_ptr with custom deleter)
    std::unique_ptr<copt_prob, COPTfreemodelT> m_model;
};
