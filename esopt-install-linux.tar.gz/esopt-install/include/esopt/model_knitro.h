#pragma once
#include "knitro.h"
#include "model_base.h"
#include "dylib.h"
#include "variable_expression.h"
#include "constraint.h"
#include "nleval.hpp"
#include "nlexpr.hpp"
// #include "solver_common.hpp"
#include "tcc_interface.hpp"

#include <map>
#include <vector>

#define KNITRO_APILIST \
    B(KN_new); \
    B(KN_free); \
    B(KN_set_var_name); \
    B(KN_add_con); \
    B(KN_add_var); \
    B(KN_set_con_lobnd); \
    B(KN_set_con_upbnd); \
    B(KN_set_con_eqbnd); \
    B(KN_add_obj_constant); \
    B(KN_add_obj_linear_struct); \
    B(KN_add_con_linear_struct_one); \
    B(KN_add_con_quadratic_struct_one); \
    B(KN_add_con_constant);\
    B(KN_set_con_name);     \
    B(KN_get_obj_value); \
    B(KN_get_var_primal_value); \
    B(KN_solve); \
    B(KN_set_obj_goal); \
    B(KN_set_var_upbnd); \
    B(KN_set_var_lobnd); \
    B(KN_set_var_type); \
    B(KN_load_param_file); \
    B(KN_add_eval_callback); \
    B(KN_set_cb_grad); \
    B(KN_set_cb_hess); \
    B(KN_set_cb_gradopt); \
    B(KN_add_eval_callback_one); \
    B(KN_set_cb_user_params); \
    B(KN_set_int_param); \
    B(KN_set_double_param); \
    B(KN_set_char_param);   \
    B(KN_set_int_param_by_name); \
    B(KN_set_double_param_by_name); \
    B(KN_set_char_param_by_name);   \
    B(KN_add_eval_callback_all);    \
    B(KN_get_solution);         \
    B(KN_set_var_types_all);    \
    B(KN_set_con_upbnds_all);   \
    B(KN_set_con_lobnds_all);   \
    B(KN_add_cons);             \
    B(KN_set_var_upbnds_all);   \
    B(KN_set_var_lobnds_all);   \
    B(KN_add_vars);             \
    B(KN_set_var_primal_init_values);   \
    B(KN_set_var_primal_init_values_all); \
    B(KN_set_var_primal_init_value);

namespace knitro
{
#define B DYLIB_EXTERN_DECLARE
KNITRO_APILIST
#undef B

bool is_library_loaded();

bool MODEL_API load_library(const std::string &path);
} //namespace knitro


struct KnitroResult
{
	bool is_valid = false;
	// store results
	std::vector<double> x, g, mult_g, mult_x_L, mult_x_U;
	double obj_val;
};

struct KnitrofreeproblemT
{
	void operator()(KN_context* model) const
	{
		knitro::KN_free(&model);
	};
};

class MODEL_API KnitroModel : public ModelBase
{
public:
    using ModelBase::set_parameter;

    KnitroModel();
    ~KnitroModel();

    void init();
    void close();

    VariableIndex add_variable(double lb, double ub, VariableDomain domain = VariableDomain::Continuous,
                               const char *name = nullptr) override;
    double get_variable_lb(const VariableIndex &variable);
    double get_variable_ub(const VariableIndex &variable);
    void set_variable_lb(const VariableIndex &variable, double lb);
    void set_variable_ub(const VariableIndex &variable, double ub);
    void set_variable_bounds(const VariableIndex &variable, double lb, double ub) override;

    double get_variable_start(const VariableIndex &variable);
    void set_variable_start(const VariableIndex &variable, double start);

    std::string get_variable_name(const VariableIndex &variable);
    void set_variable_name(const VariableIndex &variable, const std::string &name);

    double get_variable_value(const VariableIndex &variable) override;


    double get_obj_value();
    double get_constraint_primal(const ConstraintIndex &constraint);
    double get_constraint_dual(const ConstraintIndex &constraint);

    ConstraintIndex add_linear_constraint(const ScalarAffineFunction &f, ConstraintSense sense, double rhs,
                                          const char *name = nullptr) override;
    ConstraintIndex add_linear_constraint(const ScalarAffineFunction &f,
                                          const std::tuple<double, double> &interval,
                                          const char *name = nullptr) override;

    ConstraintIndex add_quadratic_constraint(const ScalarQuadraticFunction &f,
                                             ConstraintSense sense, double rhs,
                                             const char *name = nullptr) override;
    ConstraintIndex add_quadratic_constraint(const ScalarQuadraticFunction &f,
                                             const std::tuple<double, double> &interval,
                                             const char *name = nullptr) override;

    NLConstraintIndex add_nl_constraint(const NLExpr &expr, ConstraintSense sense, double rhs,
                                        const char *name = nullptr);
    NLConstraintIndex add_nl_constraint(const NLExpr &expr, const std::tuple<double, double> &interval,
                                        const char *name = nullptr);

    NLConstraintIndex add_nl_constraint(const ExpressionHandle &expr, ConstraintSense sense, double rhs,
                                        const char *name = nullptr) override;
    NLConstraintIndex add_nl_constraint(const ExpressionHandle &expr, const std::tuple<double, double> &interval,
                                        const char *name = nullptr) override;
    void set_objective(const ScalarAffineFunction &expr, ObjectiveSense sense) override;
    void set_objective(const ScalarQuadraticFunction &expr, ObjectiveSense sense) override;
    void set_objective(const ExprBuilder &expr, ObjectiveSense sense) override;
	void set_variable_domain(const VariableIndex &variable, const VariableDomain &domain);

	int set_option_int_by_code(const int &code, int value);
	int set_option_double_by_code(const int &code, double value);
	int set_option_string_by_code(const int &code, const std::string &value);

    void _set_linear_objective(const ScalarAffineFunction &expr);
    void _set_quadratic_objective(const ScalarQuadraticFunction &expr);


    void add_nl_objective(const ExpressionHandle &expr) override;
    void add_nl_objective(const NLExpr &expr);

    // void clear_nl_objective();

    void analyze_structure();
    void optimize() override;


    /*
     * record the constraint indices mapping from the monotonic one (the order of adding
     * constraint) to the reordered one (linear, quadratic, NL group 0 -> con0, con1 ,..., conN0, NL
     * group1 -> con0, con1,..., conN1)
     */






    int m_status;

    // ModelBase interface methods
    bool supports_model_attribute(ModelAttributeDouble attribute, bool changeable) override;
    bool supports_model_attribute(ModelAttributeInt attribute, bool changeable) override;
    bool supports_model_attribute(ModelAttributeString attribute, bool changeable) override;
    double get_model_attribute(ModelAttributeDouble attribute) override;
    int get_model_attribute(ModelAttributeInt attribute) override;
    std::string get_model_attribute(ModelAttributeString attribute) override;
    void set_model_attribute(ModelAttributeDouble attribute, double value) override;
    void set_model_attribute(ModelAttributeInt attribute, int value) override;
    void set_model_attribute(ModelAttributeString attribute, const char *value) override;

    bool supports_variable_attribute(VariableAttributeDouble attribute, bool changeable) override;
    bool supports_variable_attribute(VariableAttributeInt attribute, bool changeable) override;
    bool supports_variable_attribute(VariableAttributeString attribute, bool changeable) override;
    double get_variable_attribute(const VariableIndex &variable, VariableAttributeDouble attribute) override;
    int get_variable_attribute(const VariableIndex &variable, VariableAttributeInt attribute) override;
    std::string get_variable_attribute(const VariableIndex &variable, VariableAttributeString attribute) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeDouble attribute, double value) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeInt attribute, int value) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeString attribute, const char *value) override;

    bool supports_constraint_attribute(ConstraintAttributeDouble attribute, bool changeable) override;
    bool supports_constraint_attribute(ConstraintAttributeInt attribute, bool changeable) override;
    bool supports_constraint_attribute(ConstraintAttributeString attribute, bool changeable) override;
    double get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeDouble attribute) override;
    int get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeInt attribute) override;
    std::string get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeString attribute) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeDouble attribute, double value) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeInt attribute, int value) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeString attribute, const char *value) override;

    void set_parameter(const char *name, double value) override;
    void set_parameter(const char *name, int value) override;
    void set_parameter(const char *name, const char *value) override;
    void set_parameter();

    ObjectiveSense get_obj_sense();
    void set_obj_sense(ObjectiveSense sense);
    int _variable_index(const VariableIndex &variable);
    int _constraint_index(const ConstraintIndex &constraint);
    int _constraint_internal_index(const ConstraintIndex &constraint);

private:
    TCCInstance tccInst;
    class Impl;
    std::unique_ptr<Impl> pImpl;

    /* Members */

    size_t n_variables = 0;

    size_t n_nl_constraints = 0;
    bool m_is_dirty = true;
    bool set_start_point = false;
	std::unique_ptr<KN_context, KnitrofreeproblemT> m_problem = nullptr;
	KnitroResult m_result;
	ObjectiveSense m_sense;
	std::vector<int> m_var_types;

    int get_terminationstatus();
    std::string pprint_variable(const VariableIndex &variable);

    int add_graph_index();
    void finalize_graph_instance(size_t graph_index, const ExpressionGraph &graph);
    int aggregate_nl_constraint_groups();
    int get_nl_constraint_group_representative(int group_index) const;
    int aggregate_nl_objective_groups();
    int get_nl_objective_group_representative(int group_index) const;

    void assign_nl_constraint_group_autodiff_structure(int group_index,
                                                       const AutodiffSymbolicStructure &structure);
    void assign_nl_constraint_group_autodiff_evaluator(
        int group_index, const ConstraintAutodiffEvaluator &evaluator);
    void assign_nl_objective_group_autodiff_structure(int group_index,
                                                      const AutodiffSymbolicStructure &structure);
    void assign_nl_objective_group_autodiff_evaluator(int group_index,
                                                      const ObjectiveAutodiffEvaluator &evaluator);

    ConstraintIndex add_single_nl_constraint(size_t graph_index, const ExpressionGraph &graph,
                                             double lb, double ub);
    void _find_similar_graphs();
    void _compile_evaluators();
    void _codegen_c();
    void _codegen_llvm();

    void _compute_objective_graph_hashes(std::vector<uint64_t> &hashes);
    void _compute_constraint_graph_hashes(std::vector<uint64_t> &hashes);


    friend bool kn_eval_f(int n, const double *x, bool new_x, double *obj_value, void* user_data);
    friend bool kn_eval_grad_f(int n, const double *x, bool new_x, double *grad_f, void* user_data);
    friend bool kn_eval_g(int n, const double *x, bool new_x, int m, double *g,
                   void* user_data);
    friend bool kn_eval_jac_g(int n, const double *x, bool new_x, int m, int nele_jac,
                       int *iRow, int *jCol, double *values, void* user_data);
    friend bool kn_eval_h(int n, const double *x, bool new_x, double obj_factor, int m,
                   const double *lambda, bool new_lambda, int nele_hess, int *iRow,
                   int *jCol, double *values, void* user_data);
    friend int callback (KN_context_ptr              kc,
                              CB_context_ptr             cb,
                              KN_eval_request_ptr const  evalRequest,
                              KN_eval_result_ptr  const  evalResult,
                              void              * const  user_data);
};
