#pragma once
#include "cuopt/linear_programming/cuopt_c.h"

#include "model_base.h"
#include "dylib.h"
#include "nlexpr.hpp"

#include <memory>
#include <utility>

#define CUOPT_APILIST               \
    B(cuOptCreateRangedProblem);          \
	  B(cuOptCreateQuadraticRangedProblem); \
    B(cuOptDestroyProblem);        \
    B(cuOptGetNumConstraints);     \
    B(cuOptGetNumVariables);        \
    B(cuOptGetObjectiveSense);    \
    B(cuOptGetNumNonZeros);      \
    B(cuOptGetConstraintMatrix); \
    B(cuOptGetConstraintLowerBounds); \
    B(cuOptGetConstraintUpperBounds); \
    B(cuOptGetVariableLowerBounds);     \
    B(cuOptGetVariableUpperBounds);     \
    B(cuOptGetVariableTypes);         \
    B(cuOptCreateSolverSettings);       \
    B(cuOptDestroySolverSettings);      \
    B(cuOptSetParameter);             \
    B(cuOptGetParameter);             \
    B(cuOptSetIntegerParameter);       \
    B(cuOptGetIntegerParameter);       \
    B(cuOptSetFloatParameter);         \
    B(cuOptGetFloatParameter);         \
    B(cuOptIsMIP);                   \
    B(cuOptSolve);                   \
    B(cuOptDestroySolution);        \
    B(cuOptGetTerminationStatus);   \
    B(cuOptGetErrorStatus);         \
    B(cuOptGetErrorString);         \
    B(cuOptGetPrimalSolution);      \
    B(cuOptGetObjectiveValue);     \
    B(cuOptGetDualSolution);


namespace cuopt
{
#define B DYLIB_EXTERN_DECLARE
CUOPT_APILIST
#undef B

bool is_library_loaded();

bool MODEL_API load_library(const std::string &path);
} // namespace cuopt

struct CuoptfreemodelT
{
	void operator()(void* model) const
	{
		cuopt::cuOptDestroyProblem(static_cast<cuOptOptimizationProblem*>(&model));
	};
};

struct CuoptfreesettingT
{
	void operator()(void* settings) const
	{
		cuopt::cuOptDestroySolverSettings(static_cast<cuOptSolverSettings*>(&settings));
	};
};

struct CuoptfreesolutionT
{
	void operator()(void* solution) const
	{
		cuopt::cuOptDestroySolution(static_cast<cuOptSolution*>(&solution));
	};
};

class MODEL_API CuoptModel : public ModelBase
{
public:
	using ModelBase::set_parameter;

	CuoptModel();
    ~CuoptModel();

	void init();
	void close();

	// 添加变量
	VariableIndex add_variable(double lb, double ub, VariableDomain domain = VariableDomain::Continuous,
	const char* name = nullptr) override;

	// 添加线性约束
	ConstraintIndex add_linear_constraint(const ScalarAffineFunction& f, ConstraintSense sense, double rhs,
	const char* name = nullptr) override;
	ConstraintIndex add_linear_constraint(const ScalarAffineFunction &f,
                                          const std::tuple<double, double> &interval,
                                          const char *name = nullptr) override;
    ConstraintIndex add_quadratic_constraint(const ScalarQuadraticFunction &f,
                                             ConstraintSense sense, double rhs,
                                             const char *name = nullptr) override;

    NLConstraintIndex add_nl_constraint(const ExpressionHandle &expr, ConstraintSense sense, double rhs,
                                        const char *name = nullptr) override;
	// 设置目标函数
	void set_objective(const ScalarAffineFunction& expr, ObjectiveSense sense = ObjectiveSense::Minimize) override;
	void set_objective(const ScalarQuadraticFunction &function, ObjectiveSense sense = ObjectiveSense::Minimize) override;
	void set_objective(const ExprBuilder &expr, ObjectiveSense sense) override;
    void add_nl_objective(const ExpressionHandle &expr) override;

	// 求解优化模型
	void optimize() override;

	// 设置变量上下界
	void set_variable_bounds(const VariableIndex& variable, double lb, double ub) override;
	// 获取变量值
	double get_variable_value(const VariableIndex& variable) override;

	// 获取和设置属性
	bool supports_model_attribute(ModelAttributeDouble attribute, bool changeable) override;
	bool supports_model_attribute(ModelAttributeInt attribute, bool changeable) override;
	bool supports_model_attribute(ModelAttributeString attribute, bool changeable) override;
	double get_model_attribute(ModelAttributeDouble attribute) override;
	int get_model_attribute(ModelAttributeInt attribute) override;
	std::string get_model_attribute(ModelAttributeString attribute) override;
	void set_model_attribute(ModelAttributeDouble attribute, double value) override;
	void set_model_attribute(ModelAttributeInt attribute, int value) override;
	void set_model_attribute(ModelAttributeString attribute, const char *value) override;
	
	// 变量和约束的属性的接口
	bool supports_variable_attribute(VariableAttributeDouble attribute, bool changeable) override;
	bool supports_variable_attribute(VariableAttributeInt attribute, bool changeable) override;
	bool supports_variable_attribute(VariableAttributeString attribute, bool changeable) override;
	double get_variable_attribute(const VariableIndex& variable, VariableAttributeDouble attribute) override;
	int get_variable_attribute(const VariableIndex& variable, VariableAttributeInt attribute) override;
	std::string get_variable_attribute(const VariableIndex& variable, VariableAttributeString attribute) override;
	void set_variable_attribute(const VariableIndex& variable, VariableAttributeDouble attribute, double value) override;
	void set_variable_attribute(const VariableIndex& variable, VariableAttributeInt attribute, int value) override;
	void set_variable_attribute(const VariableIndex& variable, VariableAttributeString attribute, const char *value) override;
	void set_variable_attribute(const VariableIndex &variable, VariableAttributeString attribute, VariableDomain domain);
	
	bool supports_constraint_attribute(ConstraintAttributeDouble attribute, bool changeable) override;
	bool supports_constraint_attribute(ConstraintAttributeInt attribute, bool changeable) override;
	bool supports_constraint_attribute(ConstraintAttributeString attribute, bool changeable) override;
	double get_constraint_attribute(const ConstraintIndex& constraint, ConstraintAttributeDouble attribute) override;
	int get_constraint_attribute(const ConstraintIndex& constraint, ConstraintAttributeInt attribute) override;
	std::string get_constraint_attribute(const ConstraintIndex& constraint, ConstraintAttributeString attribute) override;
	void set_constraint_attribute(const ConstraintIndex& constraint, ConstraintAttributeDouble attribute, double value) override;
	void set_constraint_attribute(const ConstraintIndex& constraint, ConstraintAttributeInt attribute, int value) override;
	void set_constraint_attribute(const ConstraintIndex& constraint, ConstraintAttributeString attribute, const char *value) override;
	
	// 设置求解器参数
	void set_parameter(const char* name, double value) override;
	void set_parameter(const char* name, int value) override;
	void set_parameter(const char* name, const char* value) override;
    // void set_parameter(const char* name, bool value);

    
	VariableDomain get_variable_type(const VariableIndex &variable);
	void set_variable_type(const VariableIndex &variable, VariableDomain domain);
	double get_variable_lower_bound(const VariableIndex &variable);
	double get_variable_upper_bound(const VariableIndex &variable);
	void set_variable_lower_bound(const VariableIndex &variable, double lb);
	void set_variable_upper_bound(const VariableIndex &variable, double ub);
    double get_constraint_primal(const ConstraintIndex &constraint);
    double get_constraint_dual(const ConstraintIndex &constraint);
    
    ObjectiveSense get_obj_sense();
    void set_obj_sense(ObjectiveSense sense);
    double get_obj_value();
        
    int _variable_index(const VariableIndex &variable);
	int _constraint_index(const ConstraintIndex &constraint);
	int _checked_constraint_index(const ConstraintIndex &constraint);
private:
	int _checked_variable_index(const VariableIndex &variable);

	void _set_affine_objective(const ScalarAffineFunction& function, ObjectiveSense sense,
		bool clear_quadratic);
	void _set_quadratic_objective(const ScalarQuadraticFunction& function, ObjectiveSense sense);
private:
    class Impl;
    std::unique_ptr<Impl> pImpl;

	size_t m_n_variables = 0;
	size_t m_n_linear_cons = 0;

    std::unique_ptr<void, CuoptfreemodelT> m_model;
    std::unique_ptr<void, CuoptfreesettingT> m_settings;
    std::unique_ptr<void, CuoptfreesolutionT> m_solutions;

};
