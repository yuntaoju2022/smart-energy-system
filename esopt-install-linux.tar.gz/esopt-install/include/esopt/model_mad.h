#pragma once
#include "libMad.h"
#include "model_base.h"
#include "dylib.h"
#include "variable_expression.h"
#include "constraint.h"
#include "nleval.hpp"
#include "nlexpr.hpp"
// #include "solver_common.hpp"
#include "tcc_interface.hpp"

#include <map>
#include <vector>

#define MAD_APILIST \
    B(libmad_create_options_dict); \
    B(libmad_set_int64_option); \
    B(libmad_set_double_option); \
    B(libmad_set_bool_option); \
    B(libmad_set_string_option); \
    B(libmad_delete_options_dict); \
    B(libmad_nlpmodel_create); \
    B(libmad_nlpmodel_set_numerics); \
    B(madnlp_get_obj); \
    B(madnlp_get_solution); \
    B(madnlp_get_constraints); \
    B(madnlp_get_multipliers);  \
    B(madnlp_get_multipliers_L); \
    B(madnlp_get_multipliers_U);    \
    B(madnlp_get_success); \
    B(madnlp_get_status); \
    B(madnlp_delete_stats);\
    B(madnlp_create_solver);     \
    B(madnlp_delete_solver); \
    B(madnlp_solve); 

namespace mad
{
#define B DYLIB_EXTERN_DECLARE
MAD_APILIST
#undef B

bool is_library_loaded();

bool MODEL_API load_library(const std::string &path);
} //namespace mad


struct MadResult
{
	bool is_valid = false;
	// store results
	std::vector<double> x, g, mult_g, mult_x_L, mult_x_U;
	double obj_val;
};

struct MadfreestatsT
{
	void operator()(MadNLPExecutionStats* stats) const
	{
		mad::madnlp_delete_stats(stats);
	};
};

struct MadfreesolverT
{
    void operator()(MadNLPSolver *solver) const
    {
        mad::madnlp_delete_solver(solver);
    };
};

class MODEL_API MadModel : public ModelBase
{
public:
    MadModel();
    ~MadModel();

    void init();
    void close();

    VariableIndex add_variable(double lb, double ub, VariableDomain domain = VariableDomain::Continuous,
                               const char *name = nullptr) override;
    double get_variable_lb(const VariableIndex &variable);
    double get_variable_ub(const VariableIndex &variable);
    void set_variable_lb(const VariableIndex &variable, double lb);
    void set_variable_ub(const VariableIndex &variable, double ub);
    void set_variable_bounds(const VariableIndex &variable, double lb, double ub) override;

    double get_variable_start(const VariableIndex &variable);
    void set_variable_start(const VariableIndex &variable, double start);

    std::string get_variable_name(const VariableIndex &variable);
    void set_variable_name(const VariableIndex &variable, const std::string &name);

    double get_variable_value(const VariableIndex &variable) override;


    double get_obj_value();
    double get_constraint_primal(const ConstraintIndex &constraint);
    double get_constraint_dual(const ConstraintIndex &constraint);

    ConstraintIndex add_linear_constraint(const ScalarAffineFunction &f, ConstraintSense sense, double rhs,
                                          const char *name = nullptr) override;
    ConstraintIndex add_linear_constraint(const ScalarAffineFunction &f,
                                          const std::tuple<double, double> &interval,
                                          const char *name = nullptr) override;

    ConstraintIndex add_quadratic_constraint(const ScalarQuadraticFunction &f,
                                             ConstraintSense sense, double rhs,
                                             const char *name = nullptr) override;
    ConstraintIndex add_quadratic_constraint(const ScalarQuadraticFunction &f,
                                             const std::tuple<double, double> &interval,
                                             const char *name = nullptr) override;

    NLConstraintIndex add_nl_constraint(const NLExpr &expr, ConstraintSense sense, double rhs,
                                        const char *name = nullptr);
    NLConstraintIndex add_nl_constraint(const NLExpr &expr, const std::tuple<double, double> &interval,
                                        const char *name = nullptr);

    NLConstraintIndex add_nl_constraint(const ExpressionHandle &expr, ConstraintSense sense, double rhs,
                                        const char *name = nullptr) override;
    NLConstraintIndex add_nl_constraint(const ExpressionHandle &expr, const std::tuple<double, double> &interval,
                                        const char *name = nullptr) override;
    void set_objective(const ScalarAffineFunction &expr, ObjectiveSense sense) override;
    void set_objective(const ScalarQuadraticFunction &expr, ObjectiveSense sense) override;
    void set_objective(const ExprBuilder &expr, ObjectiveSense sense) override;
	void set_variable_domain(const VariableIndex &variable, const VariableDomain &domain);

	int set_option_int_by_code(const int &code, int value);
	int set_option_double_by_code(const int &code, double value);
	int set_option_string_by_code(const int &code, const std::string &value);

    void _set_linear_objective(const ScalarAffineFunction &expr);
    void _set_quadratic_objective(const ScalarQuadraticFunction &expr);


    void add_nl_objective(const ExpressionHandle &expr) override;
    void add_nl_objective(const NLExpr &expr);

    // void clear_nl_objective();

    void analyze_structure();
    void optimize() override;



    long long int m_status;

    // ModelBase interface methods
    bool supports_model_attribute(ModelAttributeDouble attribute, bool changeable) override;
    bool supports_model_attribute(ModelAttributeInt attribute, bool changeable) override;
    bool supports_model_attribute(ModelAttributeString attribute, bool changeable) override;
    double get_model_attribute(ModelAttributeDouble attribute) override;
    int get_model_attribute(ModelAttributeInt attribute) override;
    std::string get_model_attribute(ModelAttributeString attribute) override;
    void set_model_attribute(ModelAttributeDouble attribute, double value) override;
    void set_model_attribute(ModelAttributeInt attribute, int value) override;
    void set_model_attribute(ModelAttributeString attribute, const char *value) override;

    bool supports_variable_attribute(VariableAttributeDouble attribute, bool changeable) override;
    bool supports_variable_attribute(VariableAttributeInt attribute, bool changeable) override;
    bool supports_variable_attribute(VariableAttributeString attribute, bool changeable) override;
    double get_variable_attribute(const VariableIndex &variable, VariableAttributeDouble attribute) override;
    int get_variable_attribute(const VariableIndex &variable, VariableAttributeInt attribute) override;
    std::string get_variable_attribute(const VariableIndex &variable, VariableAttributeString attribute) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeDouble attribute, double value) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeInt attribute, int value) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeString attribute, const char *value) override;

    bool supports_constraint_attribute(ConstraintAttributeDouble attribute, bool changeable) override;
    bool supports_constraint_attribute(ConstraintAttributeInt attribute, bool changeable) override;
    bool supports_constraint_attribute(ConstraintAttributeString attribute, bool changeable) override;
    double get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeDouble attribute) override;
    int get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeInt attribute) override;
    std::string get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeString attribute) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeDouble attribute, double value) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeInt attribute, int value) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeString attribute, const char *value) override;

    void set_parameter(const char *name, double value) override;
    void set_parameter(const char *name, int value) override;
    void set_parameter(const char *name, const char *value) override;
    void set_parameter(const char *name, bool value) override;

    ObjectiveSense get_obj_sense();
    void set_obj_sense(ObjectiveSense sense);
    int _variable_index(const VariableIndex &variable);
    int _constraint_index(const ConstraintIndex &constraint);
    int _constraint_internal_index(const ConstraintIndex &constraint);

    const size_t get_num_vars() const;
    const size_t get_num_cons() const;
    const size_t get_jac_nnz() const;
    const size_t get_hess_nnz() const;

private:
    TCCInstance tccInst;
    class Impl;
    std::unique_ptr<Impl> pImpl;

    /* Members */
    size_t n_variables = 0;
    size_t n_constraints = 0;
    size_t n_nl_constraints = 0;

    bool m_is_dirty = true;
    bool set_start_point = false;
	// std::unique_ptr<CNLPModel> m_problem = nullptr;
	std::unique_ptr<MadNLPSolver, MadfreesolverT> m_solver = nullptr;
	std::unique_ptr<MadNLPExecutionStats, MadfreestatsT> m_stats = nullptr;

	MadResult m_result;
	ObjectiveSense m_sense;
	std::vector<int> m_var_types;

    std::string pprint_variable(const VariableIndex &variable);

    int add_graph_index();
    void finalize_graph_instance(size_t graph_index, const ExpressionGraph &graph);
    int aggregate_nl_constraint_groups();
    int get_nl_constraint_group_representative(int group_index) const;
    int aggregate_nl_objective_groups();
    int get_nl_objective_group_representative(int group_index) const;

    void assign_nl_constraint_group_autodiff_structure(int group_index,
                                                       const AutodiffSymbolicStructure &structure);
    void assign_nl_constraint_group_autodiff_evaluator(
        int group_index, const ConstraintAutodiffEvaluator &evaluator);
    void assign_nl_objective_group_autodiff_structure(int group_index,
                                                      const AutodiffSymbolicStructure &structure);
    void assign_nl_objective_group_autodiff_evaluator(int group_index,
                                                      const ObjectiveAutodiffEvaluator &evaluator);

    ConstraintIndex add_single_nl_constraint(size_t graph_index, const ExpressionGraph &graph,
                                             double lb, double ub);


    void _find_similar_graphs();
    void _compile_evaluators();
    void _codegen_c();
    void _codegen_llvm();

    friend bool mad_eval_f(int n, const double *x, bool new_x, double *obj_value, void* user_data);
    friend bool mad_eval_grad_f(int n, const double *x, bool new_x, double *grad_f, void* user_data);
    friend bool mad_eval_g(int n, const double *x, bool new_x, int m, double *g,
                   void* user_data);
    friend bool mad_eval_jac_g(int n, const double *x, bool new_x, int m, int nele_jac,
                       long long* iRow, long long* jCol, double *values, void* user_data);
    friend bool mad_eval_h(int n, const double *x, bool new_x, double obj_factor, int m,
                   const double *lambda, bool new_lambda, int nele_hess, long long* iRow,
                   long long* jCol, double *values, void* user_data);

};
