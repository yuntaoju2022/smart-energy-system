#ifndef _LIBMAD_H
#define _LIBMAD_H

#ifdef __cplusplus
extern "C" {
#endif


#include <stdbool.h>
#include <stdint.h>

#define libmad_int long long int
#define libmad_real double

#define LIBMAD_CCOPT_VARVAR 0
#define LIBMAD_CCOPT_VARCON 1
#define LIBMAD_CCOPT_CONVAR 2
#define LIBMAD_CCOPT_CONCON 3

// function pointer types
typedef int (*NlpConstrJacStructure)(libmad_int*, libmad_int*, void*);
typedef int (*NlpLagHessStructure)(libmad_int*, libmad_int*, void*);
typedef int (*NlpEvalObj)(const libmad_real*, libmad_real*, void*);
typedef int (*NlpEvalConstr)(const libmad_real*, libmad_real*, void*);
typedef int (*NlpEvalObjGrad)(const libmad_real*, libmad_real*, void*);
typedef int (*NlpEvalConstrJac)(const libmad_real*, libmad_real*, void*);
typedef int (*NlpEvalLagHess)(libmad_real, const libmad_real*, const libmad_real*, libmad_real*, void*);

typedef struct OptsDict OptsDict;
typedef struct CNLPModel CNLPModel;
typedef struct MadNLPExecutionStats MadNLPExecutionStats;
typedef struct MadNLPSolver MadNLPSolver;
typedef struct CMPCCModel CMPCCModel;
typedef struct CCOptExecutionStats CCOptExecutionStats;
typedef struct RelaxationSolver RelaxationSolver;

int libmad_create_options_dict(OptsDict** opts_ptr);

int libmad_set_int64_option(OptsDict* opts_ptr, const char* name, libmad_int val);

int libmad_set_double_option(OptsDict* opts_ptr, const char* name, libmad_real val);

int libmad_set_bool_option(OptsDict* opts_ptr, const char* name, bool val);

int libmad_set_string_option(OptsDict* opts_ptr, const char* name, const char* val);

int libmad_delete_options_dict(OptsDict* stats_ptr);

int libmad_nlpmodel_create(CNLPModel** nlp_ptr_ptr,
const char* name,
libmad_int nvar, libmad_int ncon,
libmad_int nnzj, libmad_int nnzh,
NlpConstrJacStructure jac_struct, NlpLagHessStructure hess_struct,
NlpEvalObj eval_f, NlpEvalConstr eval_g,
NlpEvalObjGrad eval_grad_f, NlpEvalConstrJac eval_jac_g,
NlpEvalLagHess eval_h,
void* user_data);

int libmad_nlpmodel_set_numerics(CNLPModel* nlp_ptr,
 const libmad_real* x0, const libmad_real* y0,
 const libmad_real* lvar, const libmad_real* uvar,
 const libmad_real* lcon, const libmad_real* ucon
);

int madnlp_get_obj(MadNLPExecutionStats* stats_ptr, libmad_real* out);

int madnlp_get_solution(MadNLPExecutionStats* stats_ptr, libmad_real* out);

int madnlp_get_constraints(MadNLPExecutionStats* stats_ptr, libmad_real* out);

int madnlp_get_multipliers(MadNLPExecutionStats* stats_ptr, libmad_real* out);

int madnlp_get_multipliers_L(MadNLPExecutionStats* stats_ptr, libmad_real* out);

int madnlp_get_multipliers_U(MadNLPExecutionStats* stats_ptr, libmad_real* out);

int madnlp_get_bound_multipliers(MadNLPExecutionStats* stats_ptr, libmad_real* out);

int madnlp_get_success(MadNLPExecutionStats* stats_ptr, bool* out);

int madnlp_get_iters(MadNLPExecutionStats* stats_ptr, libmad_int* out);

int madnlp_get_total_wall_time(MadNLPExecutionStats* stats_ptr, libmad_real* out);

int madnlp_get_primal_feas(MadNLPExecutionStats* stats_ptr, libmad_real* out);

int madnlp_get_dual_feas(MadNLPExecutionStats* stats_ptr, libmad_real* out);

int madnlp_get_status(MadNLPExecutionStats* stats_ptr, libmad_int* out);

int madnlp_delete_stats(MadNLPExecutionStats* stats_ptr);

int madnlp_create_solver(MadNLPSolver** solver_ptr_ptr, CNLPModel* nlp_ptr, OptsDict* opts_ptr);

int madnlp_delete_solver(MadNLPSolver* solver_ptr);

int madnlp_solve(MadNLPSolver* solver_ptr, OptsDict* opts_ptr, MadNLPExecutionStats** stats_ptr_ptr);

int libmad_mpccmodel_create(CMPCCModel** mpcc_ptr_ptr,
CNLPModel* nlp_ptr,
libmad_int ncc,
const libmad_int* ind_cc1, const libmad_int* ind_cc2,
const libmad_int* cctypes
);

int libmad_mpccmodel_set_numerics(CMPCCModel* mpcc_ptr,
const libmad_real* x0, const libmad_real* y0,
const libmad_real* lvar, const libmad_real* uvar,
const libmad_real* lcon, const libmad_real* ucon
);

int ccopt_relaxation_get_obj(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_solution(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_constraints(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_multipliers(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_multipliers_L(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_multipliers_U(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_bound_multipliers(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_success(CCOptExecutionStats* stats_ptr, bool* out);

int ccopt_relaxation_get_iters(CCOptExecutionStats* stats_ptr, libmad_int* out);

int ccopt_relaxation_get_total_wall_time(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_primal_feas(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_dual_feas(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_status(CCOptExecutionStats* stats_ptr, libmad_int* out);

int ccopt_relaxation_get_cc_feas(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_multipliers_x1(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_get_multipliers_x2(CCOptExecutionStats* stats_ptr, libmad_real* out);

int ccopt_relaxation_delete_stats(CCOptExecutionStats* stats_ptr);

int ccopt_relaxation_create_solver(RelaxationSolver** solver_ptr_ptr, CMPCCModel* mpcc_ptr, OptsDict* nlp_opts_ptr, OptsDict* mpcc_opts_ptr);

int ccopt_relaxation_delete_solver(RelaxationSolver* solver_ptr);

int ccopt_relaxation_solve(RelaxationSolver* solver_ptr, OptsDict* nlp_opts_ptr, CCOptExecutionStats** stats_ptr_ptr);

#ifdef __cplusplus
}
#endif

#endif // _LIBMAD_H

