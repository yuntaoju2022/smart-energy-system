#pragma once
#include "model_base.h"
#include "dylib.h"
#include "Uno_C_API.h"
#include "variable_expression.h"
#include "constraint.h"
#include "nleval.hpp"
#include "nlexpr.hpp"
#include "tcc_interface.hpp"

#include <map>
#include <vector>
#include <memory>


// For storing ExpressionGraph instances
#include <unordered_map>



#define UNO_APILIST \
    B(uno_create_model); \
    B(uno_destroy_model); \
    B(uno_set_variables_lower_bounds);   \
    B(uno_set_variables_upper_bounds);  \
    B(uno_set_variable_lower_bound);  \
    B(uno_set_variable_upper_bound);  \
    B(uno_set_objective);               \
    B(uno_set_constraints);             \
    B(uno_set_constraints_lower_bounds); \
    B(uno_set_constraints_upper_bounds); \
    B(uno_set_constraint_lower_bound);      \
    B(uno_set_constraint_upper_bound);      \
    B(uno_set_lagrangian_hessian); \
    B(uno_set_user_data); \
    B(uno_create_solver); \
    B(uno_destroy_solver); \
    B(uno_set_solver_integer_option);   \
    B(uno_set_solver_double_option);    \
    B(uno_set_solver_string_option);    \
    B(uno_set_solver_bool_option);      \
    B(uno_set_initial_primal_iterate);  \
    B(uno_optimize);                    \
    B(uno_get_optimization_status); \
    B(uno_get_solution_status);     \
    B(uno_get_solution_objective);  \
    B(uno_get_primal_solution);     \
    B(uno_get_constraint_dual_solution);    \
    B(uno_set_solver_preset);       \
    B(uno_load_solver_option_file);



namespace uno
{
#define B DYLIB_EXTERN_DECLARE
UNO_APILIST
#undef B

bool is_library_loaded();
bool MODEL_API load_library(const std::string &path);
} // namespace uno

using UnoProblemInfo = void;
using UnoSolverInfo = void;
using UserDataPtr = void*;

struct UnofreeproblemT
{
    void operator()(UnoProblemInfo *model) const
    {
        uno::uno_destroy_model(model);
    };
};

struct UnofreesolverT
{
    void operator()(UnoSolverInfo *solver) const
    {
        uno::uno_destroy_solver(solver);
    };
};

struct UnoResult
{
    bool is_valid = false;
    // store results
    std::vector<double> x, g, mult_g, mult_x_L, mult_x_U;
    double obj_val;
};

class MODEL_API UNOModel : public ModelBase
{
public:
    UNOModel();
    ~UNOModel();

    void init();
    void close();

    VariableIndex add_variable(double lb, double ub, VariableDomain domain = VariableDomain::Continuous,
                               const char *name = nullptr) override;
    double get_variable_lb(const VariableIndex &variable);
    double get_variable_ub(const VariableIndex &variable);
    void set_variable_lb(const VariableIndex &variable, double lb);
    void set_variable_ub(const VariableIndex &variable, double ub);
    void set_variable_bounds(const VariableIndex &variable, double lb, double ub) override;

    double get_variable_start(const VariableIndex &variable);
    void set_variable_start(const VariableIndex &variable, double start);

    std::string get_variable_name(const VariableIndex &variable);
    void set_variable_name(const VariableIndex &variable, const std::string &name);

    double get_variable_value(const VariableIndex &variable) override;

    std::string pprint_variable(const VariableIndex &variable);

    double get_obj_value();
    int _constraint_internal_index(const ConstraintIndex &constraint);
    double get_constraint_primal(const ConstraintIndex &constraint);
    double get_constraint_dual(const ConstraintIndex &constraint);

    ConstraintIndex add_linear_constraint(const ScalarAffineFunction &f, ConstraintSense sense, double rhs,
                                          const char *name = nullptr) override;
    ConstraintIndex add_linear_constraint(const ScalarAffineFunction &f,
                                          const std::tuple<double, double> &interval,
                                          const char *name = nullptr) override;

    ConstraintIndex add_quadratic_constraint(const ScalarQuadraticFunction &f,
                                             ConstraintSense sense, double rhs,
                                             const char *name = nullptr) override;
    ConstraintIndex add_quadratic_constraint(const ScalarQuadraticFunction &f,
                                             const std::tuple<double, double> &interval,
                                             const char *name = nullptr) override;

    NLConstraintIndex add_nl_constraint(const NLExpr &expr, ConstraintSense sense, double rhs,
                                        const char *name = nullptr);
    NLConstraintIndex add_nl_constraint(const NLExpr &expr, const std::tuple<double, double> &interval,
                                        const char *name = nullptr);

    NLConstraintIndex add_nl_constraint(const ExpressionHandle &expr, ConstraintSense sense, double rhs,
                                        const char *name = nullptr) override;
    NLConstraintIndex add_nl_constraint(const ExpressionHandle &expr, const std::tuple<double, double> &interval,
                                        const char *name = nullptr) override;
    void set_objective(const ScalarAffineFunction &expr, ObjectiveSense sense) override;
    void set_objective(const ScalarQuadraticFunction &expr, ObjectiveSense sense) override;
    void set_objective(const ExprBuilder &expr, ObjectiveSense sense) override;



    void add_nl_objective(const ExpressionHandle &expr) override;
    void add_nl_objective(const NLExpr &expr);

    // void clear_nl_objective();

    void analyze_structure();
    void optimize() override;

    // // load current solution as initial guess
    // void load_current_solution();

    // set options
    // void set_raw_option_int(const std::string &name, int value);
    // void set_raw_option_double(const std::string &name, double value);
    // void set_raw_option_string(const std::string &name, const std::string &value);

    // ModelBase interface methods
    bool supports_model_attribute(ModelAttributeDouble attribute, bool changeable) override;
    bool supports_model_attribute(ModelAttributeInt attribute, bool changeable) override;
    bool supports_model_attribute(ModelAttributeString attribute, bool changeable) override;
    double get_model_attribute(ModelAttributeDouble attribute) override;
    int get_model_attribute(ModelAttributeInt attribute) override;
    std::string get_model_attribute(ModelAttributeString attribute) override;
    void set_model_attribute(ModelAttributeDouble attribute, double value) override;
    void set_model_attribute(ModelAttributeInt attribute, int value) override;
    void set_model_attribute(ModelAttributeString attribute, const char *value) override;

    bool supports_variable_attribute(VariableAttributeDouble attribute, bool changeable) override;
    bool supports_variable_attribute(VariableAttributeInt attribute, bool changeable) override;
    bool supports_variable_attribute(VariableAttributeString attribute, bool changeable) override;
    double get_variable_attribute(const VariableIndex &variable, VariableAttributeDouble attribute) override;
    int get_variable_attribute(const VariableIndex &variable, VariableAttributeInt attribute) override;
    std::string get_variable_attribute(const VariableIndex &variable, VariableAttributeString attribute) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeDouble attribute, double value) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeInt attribute, int value) override;
    void set_variable_attribute(const VariableIndex &variable, VariableAttributeString attribute, const char *value) override;

    bool supports_constraint_attribute(ConstraintAttributeDouble attribute, bool changeable) override;
    bool supports_constraint_attribute(ConstraintAttributeInt attribute, bool changeable) override;
    bool supports_constraint_attribute(ConstraintAttributeString attribute, bool changeable) override;
    double get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeDouble attribute) override;
    int get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeInt attribute) override;
    std::string get_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeString attribute) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeDouble attribute, double value) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeInt attribute, int value) override;
    void set_constraint_attribute(const ConstraintIndex &constraint, ConstraintAttributeString attribute, const char *value) override;

    void set_parameter(const char *name, double value) override;
    void set_parameter(const char *name, int value) override;
    void set_parameter(const char *name, const char *value) override;
    void set_parameter(const char *name, bool value) override;

    void load_option_file(const char *filename);

    ObjectiveSense get_obj_sense();
    void set_obj_sense(ObjectiveSense sense);
    int _variable_index(const VariableIndex &variable);
    int _constraint_index(const ConstraintIndex &constraint);

private:
    class Impl;
    std::unique_ptr<Impl> pImpl;

    /* Members */
    size_t n_variables = 0;
    size_t n_nl_constraints = 0;
    std::vector<double> m_var_lb, m_var_ub, m_var_init;
    std::vector<double> m_linear_con_lb, m_linear_con_ub, m_quadratic_con_lb, m_quadratic_con_ub,
        m_nl_con_lb, m_nl_con_ub, m_con_lb, m_con_ub;

    Hashmap<IndexT, std::string> m_var_names;

    std::unique_ptr<UnoProblemInfo, UnofreeproblemT> m_problem = nullptr;
    std::unique_ptr<UnoSolverInfo, UnofreesolverT> m_solver = nullptr;

    std::string option_file_path;
    bool m_is_dirty = true;
    UnoResult m_result;
    uno_int m_status;

    TCCInstance tccInst;

private:
    int add_graph_index();
    void finalize_graph_instance(size_t graph_index, const ExpressionGraph &graph);
    int aggregate_nl_constraint_groups();
    int get_nl_constraint_group_representative(int group_index) const;
    int aggregate_nl_objective_groups();
    int get_nl_objective_group_representative(int group_index) const;

    void assign_nl_constraint_group_autodiff_structure(int group_index,
                                                       const AutodiffSymbolicStructure &structure);
    void assign_nl_constraint_group_autodiff_evaluator(
        int group_index, const ConstraintAutodiffEvaluator &evaluator);
    void assign_nl_objective_group_autodiff_structure(int group_index,
                                                      const AutodiffSymbolicStructure &structure);
    void assign_nl_objective_group_autodiff_evaluator(int group_index,
                                                      const ObjectiveAutodiffEvaluator &evaluator);

    ConstraintIndex add_single_nl_constraint(size_t graph_index, const ExpressionGraph &graph,
                                             double lb, double ub);
    void _find_similar_graphs();
    void _compile_evaluators();
    void _codegen_c();
    void _codegen_llvm();
    void _set_linear_objective(const ScalarAffineFunction &expr);
    void _set_quadratic_objective(const ScalarQuadraticFunction &expr);
    
    friend bool eval_f(int n, const double *x, bool new_x, double *obj_value, UserDataPtr user_data);
    friend bool eval_grad_f(int n, const double *x, bool new_x, double *grad_f, UserDataPtr user_data);
    friend bool eval_g(int n, const double *x, bool new_x, int m, double *g,
                   UserDataPtr user_data);
    friend bool eval_jac_g(int n, const double *x, bool new_x, int m, int nele_jac,
                       int *iRow, int *jCol, double *values, UserDataPtr user_data);
    friend bool eval_h(int n, const double *x, bool new_x, double obj_factor, int m,
                   const double *lambda, bool new_lambda, int nele_hess, int *iRow,
                   int *jCol, double *values, UserDataPtr user_data);
};
